class MyRNNLoop(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cell : __torch__.___torch_mangle_38.MyCell
  def forward(self: __torch__.___torch_mangle_41.MyRNNLoop,
    xs: Tensor) -> Tuple[Tensor, Tensor]:
    h = torch.zeros([3, 4])
    y = torch.zeros([3, 4])
    y0 = y
    h0 = h
    for i in range(torch.size(xs, 0)):
      cell = self.cell
      _0 = (cell).forward(torch.select(xs, 0, i), h0, )
      y1, h1, = _0
      y0, h0 = y1, h1
    return (y0, h0)
