class MyDecisionGate(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.___torch_mangle_30.MyDecisionGate,
    x: Tensor) -> Tensor:
    if bool(torch.gt(torch.sum(x), 0)):
      _0 = x
    else:
      _0 = torch.neg(x)
    return _0
