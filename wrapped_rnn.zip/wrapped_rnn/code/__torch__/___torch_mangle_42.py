class WrapRNN(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  loop : __torch__.___torch_mangle_41.MyRNNLoop
  def forward(self: __torch__.___torch_mangle_42.WrapRNN,
    xs: Tensor) -> Tensor:
    loop = self.loop
    _0, y, = (loop).forward(xs, )
    return torch.relu(y)
