class MyCell(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  dg : __torch__.___torch_mangle_30.MyDecisionGate
  linear : __torch__.torch.nn.modules.linear.___torch_mangle_37.Linear
  def forward(self: __torch__.___torch_mangle_38.MyCell,
    x: Tensor,
    h: Tensor) -> Tuple[Tensor, Tensor]:
    dg = self.dg
    linear = self.linear
    _0 = (dg).forward((linear).forward(x, ), )
    _1 = torch.tanh(torch.add(_0, h))
    return (_1, _1)
